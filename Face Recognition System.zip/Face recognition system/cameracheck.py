import cv2

#Init Camera
cap=cv2.VideoCapture(0) #To capture video, value 0 denotes the attached webcam on laptops 

# Face Detection
face_cascade=cv2.CascadeClassifier("haarcascade_frontalface_alt.xml")

while True:
	ret,frame=cap.read() #Reading frames and return value
	gray_frame=cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)

	if ret==False:
		continue  #Incase of no return value it will still continue

	faces=face_cascade.detectMultiScale(gray_frame,1.3,5) #faces is storing the matrix of face in list
	print (faces)


	for(x,y,w,h) in faces:
		cv2.rectangle(frame,(x,y),(x+w,y+h),(255,0,0),2) #To map rectangle around detected face

	cv2.imshow("Video Frame",frame) #Opens windowframe named "Video Frame" and shows the captured image

	#waitKey is the minimum time for which the webcam recording is on.
	key_pressed=cv2.waitKey(1) & 0xFF  #Converting 32bit number(cv2.waitKey(1)) to 8 bit number by doing bitwise and with 8 one's(hexadecimal system - 0xFF)

	if key_pressed==ord('q'):
		break 					#For stopping the webcam py pressing 'q'.

cap.release()
cv2.destroyAllWindows()